# angular-q-spread changelog

## 1.0.0
Initial release

### 1.0.1
* Fix minification
